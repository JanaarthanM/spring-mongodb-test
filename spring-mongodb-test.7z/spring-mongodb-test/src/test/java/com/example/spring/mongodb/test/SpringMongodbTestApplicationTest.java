package com.example.spring.mongodb.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongodbTestApplicationTest {

	@Test
	void contextLoads() {
	}

}
